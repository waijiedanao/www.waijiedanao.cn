if (!chrome.cookies) {
    chrome.cookies = chrome.experimental.cookies;
}
String.prototype.trim = function () {
    var re = /(^\s*)|(\s*)$/g;
    return this.replace(re, "");
}
document.addEventListener('DOMContentLoaded', function () {
    console.log('ok')
})
chrome.runtime.onMessageExternal.addListener(
    function (request, sender, sendResponse) {
        switch (request.m) {
            case 'set':
                SetCookie(request, sender, sendResponse)
                break
            case 'cookie':
                Cookie(request, sender, sendResponse)
                break
            case 'open':
                OpenTab(request, sender, sendResponse)
                break
            default: sendResponse({ msg: 'invalid m' })
        }
    })
function OpenTab(request, sender, sendResponse) {
    if (typeof request.url != 'string') return sendResponse({ msg: 'url error' })
    chrome.tabs.create({
        url: request.url
    }, function (tab) {
        sendResponse({ msg: 'ok' })
    })
}
function Cookie(request, sender, sendResponse) {
    if (typeof request.url != 'string') return sendResponse({ msg: 'url error' })
    if (typeof request.cookie != 'string') return sendResponse({ msg: 'cookie error' })
    var domain = request.url.match(/\/\/(.+?)\//)
    if (!domain) return sendResponse({ msg: 'url error.' })
    domain = domain[1]
    var cookies = request.cookie.split(';')

    if (request.del) {
        chrome.cookies.getAll({ domain: domain }, function (cookies) {
            for (var i in cookies) {
                var url = "http" + (cookies[i].secure ? "s" : "") + "://" + cookies[i].domain + cookies[i].path;
                chrome.cookies.remove({ "url": url, "name": cookies[i].name });
            }

            for (var i in cookies) {
                var c = cookies[i].trim();
                var index = c.indexOf('=')
                if (index == -1) continue;
                chrome.cookies.set({
                    url: request.url,
                    'name': c.substr(0, index),
                    'value': c.substr(index + 1)
                }, function (cookie) {
                    if (chrome.runtime.lastError) {
                        return sendResponse({ msg: chrome.runtime.lastError.message })
                    }
                })
            }
        })
    } else if (request.set) {
        for (var i in cookies) {
            var c = cookies[i].trim();
            var index = c.indexOf('=')
            if (index == -1) continue;
            chrome.cookies.set({
                url: request.url,
                'name': c.substr(0, index),
                'value': c.substr(index + 1)
            }, function (cookie) {
                if (chrome.runtime.lastError) {
                    return sendResponse({ msg: chrome.runtime.lastError.message })
                }
            })
        }
    }
    setTimeout(() => {
        chrome.cookies.getAll({ domain: domain }, function (cookies) {
            sendResponse({ msg: 'ok', cookies: cookies })
            if (request.go) OpenTab(request, sender, sendResponse)
        })
    }, 100);
}
function SetCookie(request, sender, sendResponse) {
    chrome.cookies.set(request, function (cookie) {
        if (chrome.runtime.lastError) {
            return sendResponse({ msg: chrome.runtime.lastError.message })
        }
        sendResponse({ msg: 'ok', cookie })
    })
}