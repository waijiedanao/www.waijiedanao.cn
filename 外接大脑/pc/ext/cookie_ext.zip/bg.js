if (!chrome.cookies) {
    chrome.cookies = chrome.experimental.cookies;
}
String.prototype.trim = function () {
    var re = /(^\s*)|(\s*)$/g;
    return this.replace(re, "");
}
document.addEventListener('DOMContentLoaded', function() {
	console.log('ok')
})
chrome.runtime.onMessageExternal.addListener(
    function (request, sender, sendResponse) {
        switch (request.m) {
            case 'set':
                SetCookie(request, sender, sendResponse)
                break
            case 'cookie':
                Cookie(request, sender, sendResponse)
                break
            default: sendResponse({ msg: 'invalid m' })
        }
    })
function Cookie(request, sender, sendResponse) {
    if (typeof request.cookie != 'string') return sendResponse({ msg: 'cookie error' })
    var cookies = request.cookie.split(';')
    for (var i in cookies) {
        var c = cookies[i].trim();
        var index = c.indexOf('=')
        if (index == -1) continue;
        chrome.cookies.set({
            'url': request.url,
            'name': c.substr(0, index),
            'value': c.substr(index + 1)
        }, function (cookie) {
            if (chrome.runtime.lastError) {
                return sendResponse({ msg: chrome.runtime.lastError.message })
            }
        })
    }
    setTimeout(() => {
        sendResponse({ msg: 'ok' })
    }, 100);
}
function SetCookie(request, sender, sendResponse) {
    chrome.cookies.set(request, function (cookie) {
        if (chrome.runtime.lastError) {
            return sendResponse({ msg: chrome.runtime.lastError.message })
        }
        sendResponse({ msg: 'ok', cookie })
    })
}